<?php
/**
 * Created by PhpStorm.
 * User: Hamid
 * Date: 4/19/2019
 * Time: 12:52 PM
 */

namespace App\Http\Action;


class ActionListLeague
{

}
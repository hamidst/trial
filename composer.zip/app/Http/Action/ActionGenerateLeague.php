<?php
/**
 * Created by PhpStorm.
 * User: Hamid
 * Date: 4/19/2019
 * Time: 12:46 PM
 */

namespace App\Http\Action;


class ActionGenerateLeague
{

}
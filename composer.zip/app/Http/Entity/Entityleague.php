<?php
/**
 * Created by PhpStorm.
 * User: Hamid
 * Date: 4/19/2019
 * Time: 12:58 PM
 */

namespace App\Http\Entity;


class Entityleague
{

}
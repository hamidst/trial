@extends('layout')
@section('content')
    <div id="app">
        <league-table></league-table>
    </div>
@endsection
<?php $__env->startSection('content'); ?>
    <div id="app">
        <league-table></league-table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hamid\Documents\laravel\trial\resources\views/home.blade.php ENDPATH**/ ?>